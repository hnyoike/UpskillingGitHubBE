﻿using GitRepositoryTracker.Interfaces;
using GitRepositoryTracker.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Serilog;

namespace GitRepositoryTracker.Controllers
{
    /// <summary>
    /// UsersController handles API endpoints related to user management and authentication.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class UsersController : ControllerBase
    {
        private readonly UserManager<IdentityUser> _userManager;
        private readonly IJwtService _jwtService;
        private readonly Serilog.ILogger _logger;
        public UsersController(UserManager<IdentityUser> userManager, IJwtService jwtService, Serilog.ILogger logger)
        {
            _userManager = userManager;
            _jwtService = jwtService;
            _logger = logger;
        }




        /// <summary>
        /// Creates a new user with the provided information.
        /// </summary>
        /// <param name="registerUserModel">The user registration model containing user details.</param>
        /// <returns>A response indicating whether the operation was successful.</returns>
        [HttpPost("add-user")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> PostUser(User registerUserModel)
        {
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values.SelectMany(v => v.Errors.Select(e => e.ErrorMessage));
                _logger.Warning("BadRequest received with validation errors: {@errors}", errors);
                return BadRequest(ModelState);


            }

            var user = new IdentityUser
            {
                UserName = registerUserModel.UserName,
                Email = registerUserModel.Email,
            };

            var result = await _userManager.CreateAsync(user, registerUserModel.Password);
           

            if (!result.Succeeded)
            {
                _logger.Error("Registration failed: {Errors}", result.Errors);
                return BadRequest(result.Errors);
            }

            _logger.Information("User {newuser} created a new account with password.", user.Email);
            return CreatedAtAction(nameof(GetUserByName), new { userName = user.UserName }, new { user.UserName, user.Email });

        }

        /// <summary>
        /// Retrieves a user by their username.
        /// </summary>
        /// <param name="username">The username of the user to retrieve.</param>
        /// <returns>A response containing the user's details or an error message.</returns>
        [HttpGet("{username}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<User>> GetUserByName(string username)
        {
            var user = await _userManager.FindByNameAsync(username);

            if (user == null)
            {
                _logger.Warning("User with Username {Username} not found.", username);
                return NotFound();
            }
            _logger.Information("User with Username {Username} found.", username);
            return Ok(new User { UserName = user.UserName, Email = user.Email });
        }

        /// <summary>
        /// Generates a JWT bearer token for a valid user with the provided credentials.
        /// </summary>
        /// <remarks>
        /// This method checks the provided credentials (username and password) and, if valid, generates a JWT token. The JWT token includes claims for the user's unique identifier and username. It is signed with a secret key and has an expiration time.
        /// </remarks>
        /// <param name="request">The authentication request model containing the user's credentials.</param>
        /// <returns>A response containing the JWT bearer token or an error message.</returns>
        [HttpPost("BearerToken")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<AuthenticationResponse>> CreateBearerToken(AuthenticationRequest request)
        {
            //if (!ModelState.IsValid)
            //{
            //    return BadRequest("Bad credentials");
            //}
            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).ToList();
                _logger.Warning("Login attempt failed due to invalid model state: {Errors}", errors);
                return BadRequest(new { message = "Bad credentials", errors });
            }
            var user = await _userManager.FindByNameAsync(request.UserName);

            if (user == null)
            {
                _logger.Warning("User with username {Username} not found.", request.UserName);
                return BadRequest("Bad credentials");
            }

            var isPasswordValid = await _userManager.CheckPasswordAsync(user, request.Password);

            //if (!isPasswordValid)
            //{
            //    return BadRequest("Bad credentials");
            //}
            if (!isPasswordValid)
            {
                _logger.Warning("Password validation failed for user {UserId}", user.UserName);
                return BadRequest("Bad credentials");
            }

            var token = _jwtService.CreateToken(user);
            _logger.Information("User {Username} successfully logged in. Token: {Token}", user.UserName, token);


            return Ok(token);
        }
    }
}
