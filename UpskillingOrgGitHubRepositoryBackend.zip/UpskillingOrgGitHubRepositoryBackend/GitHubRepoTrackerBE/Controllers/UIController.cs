﻿using AutoMapper;
using GitRepositoryTracker.DTO;
using GitRepositoryTracker.Interfaces;
using GitRepositoryTracker.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualBasic;
using Serilog;
using System.Reflection.Metadata;
using System;
using System.Net.NetworkInformation;
using AutoMapper.Execution;
using GitRepositoryTracker.Models;
using Serilog.Filters;

namespace GitRepositoryTracker.Controllers
{
    /// <summary>
    /// UIController handles API endpoints for retrieving repository, topic, and language information.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class UIController : ControllerBase
    {
        private readonly IUIGenericRepository _uIGenericRepository;
        private readonly IMapper _mapper;

        private readonly Serilog.ILogger _logger;

        public UIController(IUIGenericRepository uIGenericRepository, IMapper mapper, Serilog.ILogger logger)
        {
            _uIGenericRepository = uIGenericRepository;
            _mapper = mapper;
            logger = _logger;
        }

        /// <summary>
        /// Retrieves a paginated list of all repositories.
        /// </summary>
        /// <param name="pageNumber">The page number to retrieve.</param>
        /// <param name="pageSize">The number of items per page.</param>
        /// <returns>A response indicating whether the operation was successful and a paginated list of RepositoryDto objects.</returns>
        [Authorize]
        [HttpGet("all-repositories")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<PaginatedResponse<RepositoryDto>>> GetAllRepostories([FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10)
        {

            //var repositories = await _uIGenericRepository.GetAllRepositoriesAsync(pageNumber, pageSize);
            //if (repositories == null || !repositories.Any())
            //{
            //    return NotFound();
            //}

            //return Ok(new PaginatedResponse<RepositoryDto>(repositories));
            _logger.Information("Fetching repositories for page number {PageNumber} with page size {PageSize}", pageNumber, pageSize);

            try
            {
                var repositories = await _uIGenericRepository.GetAllRepositoriesAsync(pageNumber, pageSize);
                if (repositories == null || !repositories.Any())
                {
                    _logger.Warning("No repositories found for page number {PageNumber} with page size {PageSize}", pageNumber, pageSize);
                    return NotFound();
                }

                _logger.Information("{Count} repositories found for page number {PageNumber} with page size {PageSize}", repositories.Count(), pageNumber, pageSize);
                return Ok(new PaginatedResponse<RepositoryDto>(repositories));
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "An error occurred while fetching repositories for page number {PageNumber} with page size {PageSize}", pageNumber, pageSize);
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while fetching repositories");
            }
        }

        /// <summary>
        /// Retrieves a paginated list of repositories sorted by the updated_at field.
        /// </summary>
        /// <param name="pageNumber">The page number to retrieve.</param>
        /// <param name="pageSize">The number of items per page.</param>
        /// <returns>A response indicating whether the operation was successful and a paginated list of RepositoryDto objects sorted by updated_at.</returns>
        [Authorize]
        [HttpGet("by-updated-at")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<PaginatedResponse<RepositoryDto>>> GetAllByUpdatedAt([FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10)
        {

            //var repositories = await _uIGenericRepository.GetAllByDateAsync(pageNumber, pageSize);
            //if (repositories == null || !repositories.Any())
            //{
            //    return NotFound();
            //}

            //return Ok(new PaginatedResponse<RepositoryDto>(repositories));
            _logger.Information("Fetching repositories updated at page number {PageNumber} with page size {PageSize}", pageNumber, pageSize);

            try
            {
                var repositories = await _uIGenericRepository.GetAllByDateAsync(pageNumber, pageSize);
                if (repositories == null || !repositories.Any())
                {
                    _logger.Warning("No repositories found for page number {PageNumber} with page size {PageSize}", pageNumber, pageSize);
                    return NotFound();
                }

                _logger.Information("{Count} repositories found for page number {PageNumber} with page size {PageSize}", repositories.Count(), pageNumber, pageSize);
                return Ok(new PaginatedResponse<RepositoryDto>(repositories));
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "An error occurred while fetching repositories for page number {PageNumber} with page size {PageSize}", pageNumber, pageSize);
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while fetching repositories");
            }
        }

        /// <summary>
        /// Retrieves a paginated list of repositories that have a specified topic.
        /// </summary>
        /// <param name="topicName">The name of the topic to filter by.</param>
        /// <param name="pageNumber">The page number to retrieve.</param>
        /// <param name="pageSize">The number of items per page.</param>
        /// <returns>A response indicating whether the operation was successful and a paginated list of RepositoryDto objects with the specified topic.</returns>
        [Authorize]
        [HttpGet("topic/{topicName}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<PaginatedResponse<RepositoryDto>>> GetAllByTopic(string topicName, [FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10)
        {
            //if (string.IsNullOrEmpty(topicName))
            //{
            //    return BadRequest("TopicDto parameter is required");
            //}

            //var repositories = await _uIGenericRepository.GetAllByTopicAsync(topicName, pageNumber, pageSize);

            //if (repositories == null || !repositories.Any())
            //{
            //    return NotFound();
            //}
            //return Ok(new PaginatedResponse<RepositoryDto>(repositories));


            try
            {
                if (string.IsNullOrEmpty(topicName))
                {
                    _logger.Warning("TopicDto parameter is required");
                    return BadRequest("TopicDto parameter is required");
                }

                _logger.Information("Fetching repositories by topic {TopicName} at page number {PageNumber} with page size {PageSize}", topicName, pageNumber, pageSize);

                var repositories = await _uIGenericRepository.GetAllByTopicAsync(topicName, pageNumber, pageSize);

                if (repositories == null || !repositories.Any())
                {
                    _logger.Warning("No repositories found for topic {TopicName} at page number {PageNumber} with page size {PageSize}", topicName, pageNumber, pageSize);
                    return NotFound();
                }

                _logger.Information("{Count} repositories found for topic {TopicName} at page number {PageNumber} with page size {PageSize}", repositories.Count(), topicName, pageNumber, pageSize);
                return Ok(new PaginatedResponse<RepositoryDto>(repositories));
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "An error occurred while fetching repositories by topic {TopicName} at page number {PageNumber} with page size {PageSize}", topicName, pageNumber, pageSize);
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while fetching repositories");
            }
        }

        /// <summary>
        /// Retrieves a paginated list of repositories sorted by the number of forks.
        /// </summary>
        /// <param name="pageNumber">The page number to retrieve.</param>
        /// <param name="pageSize">The number of items per page.</param>
        /// <returns>A response indicating whether the operation was successful and a paginated list of RepositoryDto objects sorted by the number of forks.</returns>
        [Authorize]
        [HttpGet("by-forks")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<PaginatedResponse<RepositoryDto>>> GetAllByNumberOfForks([FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10)
        {

            //var repositories = await _uIGenericRepository.GetAllByForksAsync(pageNumber, pageSize);
            //if (repositories == null || !repositories.Any())
            //{
            //    return NotFound();
            //}

            //return Ok(new PaginatedResponse<RepositoryDto>(repositories));

            // Logging messages are added to provide information about the execution and any encountered warnings or errors.
            //A try-catch block is included to handle exceptions and log any errors that occur during execution.
            try
            {
                _logger.Information("Fetching repositories by number of forks at page number {PageNumber} with page size {PageSize}", pageNumber, pageSize);

                var repositories = await _uIGenericRepository.GetAllByForksAsync(pageNumber, pageSize);

                if (repositories == null || !repositories.Any())
                {
                    _logger.Warning("No repositories found by number of forks at page number {PageNumber} with page size {PageSize}", pageNumber, pageSize);
                    return NotFound();
                }

                _logger.Information("{Count} repositories found by number of forks at page number {PageNumber} with page size {PageSize}", repositories.Count(), pageNumber, pageSize);
                return Ok(new PaginatedResponse<RepositoryDto>(repositories));
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "An error occurred while fetching repositories by number of forks at page number {PageNumber} with page size {PageSize}", pageNumber, pageSize);
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while fetching repositories");
            }

        }

        /// <summary>
        /// Retrieves a paginated list of repositories sorted by the number of stars.
        /// </summary>
        /// <param name="pageNumber">The page number to retrieve.</param>
        /// <param name="pageSize">The number of items per page.</param>
        /// <returns>A response indicating whether the operation was successful and a paginated list of RepositoryDto objects sorted by the number of stars.</returns>
        [Authorize]
        [HttpGet("by-stars")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<PaginatedResponse<RepositoryDto>>> GetAllByNumberOfStars([FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10)
        {

            //var repositories = await _uIGenericRepository.GetAllByStarsAsync(pageNumber, pageSize);
            //if (repositories == null || !repositories.Any())
            //{
            //    return NotFound();
            //}

            //return Ok(new PaginatedResponse<RepositoryDto>(repositories));

            // Logging messages are added to provide information about the execution and any encountered warnings or errors.
            //A try-catch block is included to handle exceptions and log any errors that occur during execution.

            try
            {
                _logger.Information("Fetching repositories by number of stars at page number {PageNumber} with page size {PageSize}", pageNumber, pageSize);

                var repositories = await _uIGenericRepository.GetAllByStarsAsync(pageNumber, pageSize);

                if (repositories == null || !repositories.Any())
                {
                    _logger.Warning("No repositories found by number of stars at page number {PageNumber} with page size {PageSize}", pageNumber, pageSize);
                    return NotFound();
                }

                _logger.Information("{Count} repositories found by number of stars at page number {PageNumber} with page size {PageSize}", repositories.Count(), pageNumber, pageSize);
                return Ok(new PaginatedResponse<RepositoryDto>(repositories));
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "An error occurred while fetching repositories by number of stars at page number {PageNumber} with page size {PageSize}", pageNumber, pageSize);
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while fetching repositories");
            }
        }

        /// <summary>
        /// Retrieves a paginated list of repositories that use a specified programming language.
        /// </summary>
        /// <param name="languageName">The name of the programming language to filter by.</param>
        /// <param name="pageNumber">The page number to retrieve.</param>
        /// <param name="pageSize">The number of items per page.</param>
        /// <returns>A response indicating whether the operation was successful and a paginated list of RepositoryDto objects using the specified programming language.</returns>
        [Authorize]
        [HttpGet("language/{languageName}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<PaginatedResponse<RepositoryDto>>> GetAllByLanguage(string languageName, [FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10)
        {
            //if (string.IsNullOrEmpty(languageName))
            //{
            //    return BadRequest("Language parameter is required");
            //}
            //var repositories = await _uIGenericRepository.GetAllByLanguageAsync(languageName, pageNumber, pageSize);
            //if (repositories == null || !repositories.Any())
            //{
            //    return NotFound();
            //}

            //return Ok(new PaginatedResponse<RepositoryDto>(repositories));

// Logging messages are added to provide information about the execution and any encountered warnings or errors.
//A try-catch block is included to handle exceptions and log any errors that occur during execution.
//Logging includes details about the language being fetched, the page number, and page size.

            try
            {
                _logger.Information("Fetching repositories by language '{Language}' at page number {PageNumber} with page size {PageSize}", languageName, pageNumber, pageSize);

                if (string.IsNullOrEmpty(languageName))
                {
                    _logger.Warning("Language parameter is required but was not provided");
                    return BadRequest("Language parameter is required");
                }

                var repositories = await _uIGenericRepository.GetAllByLanguageAsync(languageName, pageNumber, pageSize);

                if (repositories == null || !repositories.Any())
                {
                    _logger.Warning("No repositories found by language '{Language}' at page number {PageNumber} with page size {PageSize}", languageName, pageNumber, pageSize);
                    return NotFound();
                }

                _logger.Information("{Count} repositories found by language '{Language}' at page number {PageNumber} with page size {PageSize}", repositories.Count(), languageName, pageNumber, pageSize);
                return Ok(new PaginatedResponse<RepositoryDto>(repositories));
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "An error occurred while fetching repositories by language '{Language}' at page number {PageNumber} with page size {PageSize}", languageName, pageNumber, pageSize);
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while fetching repositories");
            }

        }

        /// <summary>
        /// Retrieves a paginated list of all topics.
        /// </summary>
        /// <param name="pageNumber">The page number to retrieve.</param>
        /// <param name="pageSize">The number of items per page.</param>
        /// <returns>A response indicating whether the operation was successful and a paginated list of TopicDto objects.</returns>
        [Authorize]
        [HttpGet("all-topics")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<PaginatedResponse<TopicDto>>> GetAllTopics([FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10)
        {

            //var topics = await _uIGenericRepository.GetAllTopicsAsync(pageNumber, pageSize);
            //if (topics == null || !topics.Any())
            //{
            //    return NotFound();
            //}

            //return Ok(new PaginatedResponse<TopicDto>(topics));
// Logging messages are added to provide information about the execution, any warnings, errors, and the number of topics found.
//A try-catch block is included to handle exceptions and log any errors that occur during execution.
//Logging includes details about the page number and page size for fetching topics.
            try
            {
                _logger.Information("Fetching all topics at page number {PageNumber} with page size {PageSize}", pageNumber, pageSize);

                var topics = await _uIGenericRepository.GetAllTopicsAsync(pageNumber, pageSize);

                if (topics == null || !topics.Any())
                {
                    _logger.Warning("No topics found at page number {PageNumber} with page size {PageSize}", pageNumber, pageSize);
                    return NotFound();
                }

                _logger.Information("{Count} topics found at page number {PageNumber} with page size {PageSize}", topics.Count(), pageNumber, pageSize);
                return Ok(new PaginatedResponse<TopicDto>(topics));
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "An error occurred while fetching all topics at page number {PageNumber} with page size {PageSize}", pageNumber, pageSize);
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while fetching topics");
            }
        }

        /// <summary>
        /// Retrieves a paginated list of all Languages.
        /// </summary>
        /// <param name="pageNumber">The page number to retrieve.</param>
        /// <param name="pageSize">The number of items per page.</param>
        /// <returns>A response indicating whether the operation was successful and a paginated list of LanguageDto objects.</returns>
        [Authorize]
        [HttpGet("all-languages")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<PaginatedResponse<LanguageDto>>> GetAllLanguages([FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10)
        {

            //var languages = await _uIGenericRepository.GetAllLanguagesAsync(pageNumber, pageSize);
            //if (languages == null || !languages.Any())
            //{
            //    return NotFound();
            //}

            //return Ok(new PaginatedResponse<LanguageDto>(languages));
            try
            {
                _logger.Information("Fetching all languages at page number {PageNumber} with page size {PageSize}", pageNumber, pageSize);

                var languages = await _uIGenericRepository.GetAllLanguagesAsync(pageNumber, pageSize);

                if (languages == null || !languages.Any())
                {
                    _logger.Warning("No languages found at page number {PageNumber} with page size {PageSize}", pageNumber, pageSize);
                    return NotFound();
                }

                _logger.Information("{Count} languages found at page number {PageNumber} with page size {PageSize}", languages.Count(), pageNumber, pageSize);
                return Ok(new PaginatedResponse<LanguageDto>(languages));
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "An error occurred while fetching all languages at page number {PageNumber} with page size {PageSize}", pageNumber, pageSize);
                return StatusCode(StatusCodes.Status500InternalServerError, "An error occurred while fetching languages");
            }
        }
    }
}
