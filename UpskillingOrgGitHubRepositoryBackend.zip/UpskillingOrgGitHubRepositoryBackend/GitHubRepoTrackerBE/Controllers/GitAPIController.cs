﻿using AutoMapper;
using GitRepositoryTracker.DTO;
using GitRepositoryTracker.Interfaces;
using GitRepositoryTracker.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Serilog;

namespace GitRepositoryTracker.Controllers
{
    /// <summary>
    /// GitAPIController handles API endpoints related to topics and repositories.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class GitAPIController : ControllerBase
    {
        private readonly IGitAPIRepository _gitAPIRepository;
        private readonly IMapper _mapper;
        private readonly IGitHubAPIService _gitHubAPIService;
        private readonly Serilog.ILogger _logger;

        public GitAPIController(IGitAPIRepository gitAPIRepository, IMapper mapper, IGitHubAPIService gitHubAPIClient, Serilog.ILogger logger)
        {
            _gitAPIRepository = gitAPIRepository;
            _mapper = mapper;
            _gitHubAPIService = gitHubAPIClient;
            _logger = logger;
        }

        /// <summary>
        /// Adds Topics to the database.
        /// </summary>
        /// <param name="topicDtos"> A collection of topics to add.</param>
        /// <returns>A response indicating whether the operation was successful.</returns>
        [Authorize]
        [HttpPost("add_topics")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult> AddTopics(IEnumerable<TopicDto> topicDtos)
        {
            if (topicDtos == null || !topicDtos.Any())
            {
                _logger.Warning("No topics provided");
                return BadRequest("No topics provided");
            }

            var topics = _mapper.Map<IEnumerable<Topic>>(topicDtos);
            _logger.Information("Mapping {TopicDtoCount} TopicDtos to Topics", topicDtos.Count());

            await _gitAPIRepository.Addtopics(topics);
            _logger.Information("Added {TopicCount} topics to the repository", topics.Count());


            return Ok();
        }

        /// <summary>
        ///Retrieves a repository by its ID. 
        /// </summary>
        /// <param name="id"> ID of the repository to be retrieved</param>
        /// <returns>A response containing the repository DTO or an error message.</returns>
        [Authorize]
        [HttpGet("repository/{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<RepositoryDto>> GetRepositoryById(string id)
        {
            _logger.Information("Getting repository with ID: {Id}", id);
            var repository = await _gitAPIRepository.GetRepositoryById(id);

            if (repository == null)
            {
                _logger.Warning("Repository with ID: {Id} not found", id);
                return NotFound();
            }
            var repositoryDto = _mapper.Map<RepositoryDto>(repository);
            _logger.Information("Repository with ID: {Id} found and mapped to DTO", id);

            return Ok(repositoryDto);
        }

        /// <summary>
        /// Retrieves a topic by its ID.
        /// </summary>
        /// <param name="id">ID of the topic to be retrieved</param>
        /// <returns>A response containing the topic DTO or an error message.</returns>
        [Authorize]
        [HttpGet("gettopic/{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<TopicDto>> GetTopicById(int id)
        {
            _logger.Information("Getting topic with ID: {Id}", id);

            var topic = await _gitAPIRepository.GetTopicById(id);

            if (topic == null)
            {
                _logger.Warning("Topic with ID: {Id} not found", id);
                return NotFound();
            }
            var topicDto = _mapper.Map<TopicDto>(topic);
            _logger.Information("Topic with ID: {Id} found and mapped to DTO", id);

            return Ok(topicDto);
        }

        /// <summary>
        /// Adds repositories to the database based on the provided parameters.
        /// </summary>
        /// <param name="size">The size in KBs of the repositories to retrieve.</param>
        /// <param name="page">The page number to retrieve.</param>
        /// <param name="perPage">The number of repositories per page.</param>
        /// <returns>A response indicating whether the operation was successful.</returns>
        [Authorize]
        [HttpPost("repositories")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> AddRepositories(int size, int page, int perPage)
        {
            _logger.Information("Starting to add repositories with size: {Size}, page: {Page}, perPage: {PerPage}", size, page, perPage);

            try
            {
                var repositories = await _gitHubAPIService.GetAllRepositoriesBySize(size, page, perPage);
                _logger.Information("Fetched {Count} repositories from GitHub API", repositories.ToList().Count());

                await _gitAPIRepository.AddRepositories(repositories);
                _logger.Information("Repositories added to the database successfully");

                return Ok("Repositories added to database successfully.");
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error adding repositories to the database");
                return StatusCode(StatusCodes.Status500InternalServerError, $"Error adding repositories to database: {ex.Message}");
            }


        }
    }
}
