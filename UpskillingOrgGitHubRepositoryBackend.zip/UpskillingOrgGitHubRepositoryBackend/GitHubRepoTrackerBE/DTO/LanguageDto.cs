﻿namespace GitRepositoryTracker.DTO
{
    public class LanguageDto
    {
        public string LanguageName { get; set; }
    }
}
