﻿namespace GitRepositoryTracker.DTO
{
    public class TopicDto
    {

        public string TopicName { get; set; }
    }
}
