﻿namespace GitRepositoryTracker.DTO
{


    public class RepositoryTopicDto
    {
        public int TopicId { get; set; }
        public string RepositoryId { get; set; }
        public string TopicName { get; set; }

    }

}
